#include "delay.h"
#include "sys.h"
#include "oled.h"
#include "usart1.h"

/*
	@author           Hu Yinghua
	@version          V1.0
	@function name    OLED
	@description      
	@param
	@return
*/



/**
  * 坐标轴定义：
  * 左上角为(0, 0)点
  * 横向向右为X轴，取值范围：0~127
  * 纵向向下为Y轴，取值范围：0~63
  * 
  *       0             X轴           127 
  *      .------------------------------->
  *    0 |
  *      |
  *      |
  *      |
  *  Y轴 |
  *      |
  *      |
  *      |
  *   63 |
  *      v
  * 
  */


uint8_t RxData;

int main()
{	
	
	OLED_Init();
	Serial_Init();
	Delay_Init();
	
	
//	uint8_t MyArray[] = {0x42, 0x43 ,0x44, 0x45};
	OLED_ShowString(16, 0, "Hello World!", OLED_8X16);
//	
//	

	
	
	while(1)
	{		
	/*	若使用串口发送，可以删除注释  */
		//Serial_SendByte(0x41);
		//Serial_SendArray(MyArray, 4);
		//Serial_SendString("Hello World!\r\n");
		//Serial_SendNumber(12345, 5);
		//printf("Num = %d\r\n",666);
		//Serial_Printf("你好，世界");
		//delay_ms(3000);

		if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == SET)
		{
			RxData = USART_ReceiveData(USART1);
			OLED_ShowHexNum(1, 1, RxData, 2, OLED_6X8);
		}
		
		/* 若使用OLED，删除以下注释 */
		/*调用OLED_Update函数，将OLED显存数组的内容更新到OLED硬件进行显示*/
		OLED_Update();

		/*延时3000ms，观察现象*/
//		delay_ms(3000);
		
		
	}
}

